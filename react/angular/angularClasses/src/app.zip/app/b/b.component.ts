import { Component, OnInit, ViewEncapsulation, EventEmitter } from '@angular/core';

import { Display } from '../display';

@Component({
  selector: 'app-b',
  templateUrl: './b.component.html',
  styleUrls: ['./b.component.css'],
  viewProviders:[Display],
  encapsulation:ViewEncapsulation.None,
  inputs:['Pdata'],
  outputs:['childTop']
})
export class BComponent implements OnInit {
Pdata:any;
childTop=new EventEmitter();
  constructor(private obj1:Display) {
    obj1.Show();
   }

  ngOnInit(): void {
  }

  onchange(val:any){  
this.childTop.emit(val);

  }

}
