export class Display {
  constructor (){
console.log("constructor console");
 }

  Show (){
    console.log("show console here");
    }
}
